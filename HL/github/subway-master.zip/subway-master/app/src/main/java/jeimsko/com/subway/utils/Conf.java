package jeimsko.com.subway.utils;

/**
 * Created by jeimsko on 2016. 9. 9..
 */

public class Conf {

    //TODO: 퍼미션
    public static final int  REQ_CODE_REQUEST_SETTING                               = 200;
    public static final int  MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE          = 201;
    public static final int  MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE           = 202;
    public static final int  MY_PERMISSIONS_READ_PHONE_STATE                        = 203;
    public static final int  MY_PERMISSION_CALL_PHONE                               = 204;
    public static final int  MY_PERMISSION_SEND_SMS                                 = 205;
    public static final int  MY_PERMISSION_RECEIVE_SMS                              = 206;
    public static final int  MY_PERMISSION_READ_SMS                                 = 207;
    public static final int  MY_PERMISSION_CAMERA                                   = 208;
    public static final int  MY_PERMISSION_READ_CONTACTS                            = 209;
    public static final int  MY_PERMISSION_ACCESS_FIND_LOCATION                     = 210;
    public static final int  MY_PERMISSION_RECORD_AUDIO                             = 211;
    public static final int  MY_PERMISSION_READ_CONTACT_SINGLE                      = 212;
    public static final int  MY_PERMISSION_READ_CONTACT_MULTI                       = 213;
    public static final int  MY_PERMISSIONS_REQUEST_NECESSARY                       = 214;
    public static final int  MY_PERMISSIONS_NFI_OPTION_OCR                          = 215;
    public static final int  MY_PERMISSIONS_NFI_OPTION_PICTURE                      = 216;
    public static final int  MY_PERMISSIONS_NFI_OPTION_PHONE_CALL                   = 217;
    public static final int  MY_PERMISSIONS_NFI_OPTION_VIDEOCALL                    = 218;
}
