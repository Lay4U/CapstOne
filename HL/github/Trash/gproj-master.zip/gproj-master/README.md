"지하철 노선도 기반 음식점 추천 안드로이드 애플리케이션"

2016년 12월~ 2017년 2월까지 대학교 졸업작품으로 개발하였습니다.

<img src="https://user-images.githubusercontent.com/14172694/40693765-313dbf12-63f4-11e8-8ddf-48c280ed8379.png" width="90%"></img>
<img src="https://user-images.githubusercontent.com/14172694/40693768-32423050-63f4-11e8-83ea-dac41c39a438.png" width="90%">
